//
//  ViewController.swift
//  FacebookIntegration
//
//  Created by Rajith Kumar on 12/06/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit

class ViewController: UIViewController, FBSDKLoginButtonDelegate {
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("logout")
    }
    
    
    
    let loginButton: FBSDKLoginButton = {
        let button = FBSDKLoginButton()
        button.readPermissions = ["email"]
        return button
    }()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        view.addSubview(loginButton)
        loginButton.center = view.center
        loginButton.delegate = self
        
        if let token = FBSDKAccessToken.current(){
            fetchProfile()
        }
        
        
    }
    
    
    func fetchProfile() {
        print("fetching profile")
        
//        let parameter = ["" : ""]
//        FBSDKGraphRequest(graphPath: "me", parameters: parameter)
    }
    
//    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
//
//    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        print("login Completed")
    }

    func loginButtonWillLogin(_ loginButton: FBSDKLoginButton!) -> Bool {
        return true
    }


}

