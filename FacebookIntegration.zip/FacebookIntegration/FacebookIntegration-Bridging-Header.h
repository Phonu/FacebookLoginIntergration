//
//  FacebookIntegration-Bridging-Header.h
//  FacebookIntegration
//
//  Created by Rajith Kumar on 19/06/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

#ifndef FacebookIntegration_Bridging_Header_h
#define FacebookIntegration_Bridging_Header_h


#endif /* FacebookIntegration_Bridging_Header_h */
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

